/**
 * Telemetry package for sending data to NT4 or SmartDashboard.
 */
package swervelib.telemetry;