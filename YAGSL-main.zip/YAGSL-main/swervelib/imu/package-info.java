/**
 * IMUs used for controlling the robot heading. All implement {@link swervelib.imu.SwerveIMU}.
 */
package swervelib.imu;
