/**
 * Absolute encoders for the swerve drive, all implement {@link swervelib.encoders.SwerveAbsoluteEncoder}.
 */
package swervelib.encoders;
